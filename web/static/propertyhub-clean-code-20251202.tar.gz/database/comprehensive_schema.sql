-- PropertyHub Comprehensive Database Schema
-- All tables, indexes, and constraints for complete system deployment
-- Version: Production-Ready Complete Schema

-- Note: Database 'landlords_of_texas' is created by Docker environment

-- ============================================================================
-- CORE PROPERTY SYSTEM TABLES
-- ============================================================================

-- Properties table with HAR-compliant schema
CREATE TABLE IF NOT EXISTS properties (
    id SERIAL PRIMARY KEY,
    mls_id VARCHAR(50) UNIQUE,
    address TEXT NOT NULL,
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    price DECIMAL(12,2),
    description TEXT,
    images TEXT[], -- PostgreSQL array for multiple images
    listing_type VARCHAR(50),
    status VARCHAR(50) DEFAULT 'pending_images',
    listing_agent VARCHAR(200),
    listing_office VARCHAR(200),
    bedrooms INTEGER,
    bathrooms DECIMAL(3,1),
    square_feet INTEGER,
    property_type VARCHAR(100),
    source VARCHAR(50) DEFAULT 'HAR',
    har_url TEXT,
    featured_image TEXT,
    amenities TEXT,
    date_added TIMESTAMP,
    last_updated TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Additional fields for PropertyHub
    listing_agent_id VARCHAR(100),
    property_features TEXT,
    view_count INTEGER DEFAULT 0
);

-- Property photos table
CREATE TABLE IF NOT EXISTS property_photos (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id) ON DELETE CASCADE,
    mls_id VARCHAR(50),
    file_path TEXT NOT NULL,
    file_hash VARCHAR(64),
    is_primary BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- USER MANAGEMENT AND AUTHENTICATION
-- ============================================================================

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(200) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(50) DEFAULT 'admin',
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0
);

-- ============================================================================
-- LEAD MANAGEMENT AND CRM INTEGRATION
-- ============================================================================

-- Leads table for FUB integration
CREATE TABLE IF NOT EXISTS leads (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    fub_lead_id VARCHAR(100) UNIQUE,
    source VARCHAR(100) DEFAULT 'Website',
    status VARCHAR(50) DEFAULT 'new',
    tags TEXT, -- JSON array
    custom_fields TEXT, -- JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lead reengagement table
CREATE TABLE IF NOT EXISTS lead_reengagement (
    id SERIAL PRIMARY KEY,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(20),
    last_activity TIMESTAMP,
    campaign_status VARCHAR(50) DEFAULT 'active',
    engagement_score INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- BOOKING AND SHOWING MANAGEMENT  
-- ============================================================================

-- Bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    fub_lead_id VARCHAR(100),
    client_name VARCHAR(200) NOT NULL,
    client_phone VARCHAR(20),
    client_email VARCHAR(200),
    showing_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    service_type VARCHAR(100),
    preferred_time VARCHAR(50),
    reference_number VARCHAR(50) UNIQUE,
    notes TEXT,
    
    -- Additional booking fields
    duration_minutes INTEGER DEFAULT 30,
    showing_type VARCHAR(50) DEFAULT 'in-person',
    attendee_count INTEGER DEFAULT 1,
    special_requests TEXT,
    fub_synced BOOLEAN DEFAULT false,
    interest_level VARCHAR(50),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Booking status log for audit trail
CREATE TABLE IF NOT EXISTS booking_status_logs (
    id SERIAL PRIMARY KEY,
    booking_id INTEGER NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    previous_status VARCHAR(50),
    new_status VARCHAR(50) NOT NULL,
    changed_by VARCHAR(100),
    change_reason TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- CONTACT AND INQUIRY MANAGEMENT
-- ============================================================================

-- Contacts table
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(200),
    phone VARCHAR(20),
    message TEXT,
    source VARCHAR(100),
    
    -- Additional contact fields
    property_id VARCHAR(100),
    urgent BOOLEAN DEFAULT false,
    status VARCHAR(50) DEFAULT 'new',
    fub_lead_id VARCHAR(100),
    fub_synced BOOLEAN DEFAULT false,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- PRE-LISTING WORKFLOW SYSTEM
-- ============================================================================

-- Pre-listing items for operational workflow tracking
CREATE TABLE IF NOT EXISTS pre_listing_items (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Property Information
    address TEXT NOT NULL,
    full_address TEXT,
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),

    -- Status and Progress
    status VARCHAR(50) DEFAULT 'email_received',
    is_overdue BOOLEAN DEFAULT false,
    overdue_reason TEXT,

    -- Broker's Email Data
    broker_email_date TIMESTAMP,
    broker_email_subject TEXT,
    broker_email_content TEXT,
    target_listing_date TIMESTAMP,

    -- Lockbox Information
    lockbox_deadline TIMESTAMP,
    lockbox_placed_date TIMESTAMP,
    lockbox_type VARCHAR(50),
    lockbox_notes TEXT,

    -- Photo Information
    photo_scheduled_date TIMESTAMP,
    photo_expected_date TIMESTAMP,
    photo_completed_date TIMESTAMP,
    photo_status VARCHAR(50),
    photo_url TEXT,
    photo_notes TEXT,

    -- Sign Information
    sign_placed_date TIMESTAMP,
    sign_status VARCHAR(50),
    sign_notes TEXT,

    -- Pricing and Listing
    pricing_set_date TIMESTAMP,
    listing_price DECIMAL(12,2),
    mls_listed_date TIMESTAMP,
    mls_number VARCHAR(100),
    confirmed_date TIMESTAMP,

    -- Administrative
    admin_notes TEXT,
    last_alert_sent TIMESTAMP,
    manual_override BOOLEAN DEFAULT false,
    override_reason TEXT,
    
    -- Contact Information
    owner_contact TEXT,
    priority VARCHAR(20) DEFAULT 'medium'
);

-- Email alerts for overdue pre-listing items
CREATE TABLE IF NOT EXISTS email_alerts (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    pre_listing_item_id INTEGER NOT NULL REFERENCES pre_listing_items(id) ON DELETE CASCADE,
    alert_type VARCHAR(50) NOT NULL,
    alert_level VARCHAR(20) NOT NULL,
    message TEXT,

    is_sent BOOLEAN DEFAULT false,
    sent_at TIMESTAMP,
    is_resolved BOOLEAN DEFAULT false,
    resolved_at TIMESTAMP
);

-- ============================================================================
-- EMAIL PROCESSING AND AUTOMATION
-- ============================================================================

-- Incoming emails for processing
CREATE TABLE IF NOT EXISTS incoming_emails (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Email Information
    from_email VARCHAR(255) NOT NULL,
    to_email VARCHAR(255) NOT NULL,
    subject TEXT NOT NULL,
    content TEXT,
    received_at TIMESTAMP,

    -- Processing Information
    email_type VARCHAR(100),
    processing_status VARCHAR(50) DEFAULT 'pending',
    confidence DECIMAL(3,2),
    extracted_address TEXT,
    extracted_data TEXT, -- JSON

    -- Relationships
    pre_listing_item_id INTEGER REFERENCES pre_listing_items(id),
    application_id INTEGER -- Will be added when approvals table is created
);

-- Trusted email senders for automated processing
CREATE TABLE IF NOT EXISTS trusted_email_senders (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Sender Information
    sender_email VARCHAR(255) UNIQUE NOT NULL,
    sender_name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    contact_person VARCHAR(255),

    -- Email Processing Configuration
    email_type VARCHAR(100) NOT NULL,
    processing_mode VARCHAR(50) DEFAULT 'automatic',
    parsing_template TEXT,
    
    -- Status and Control
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    last_email_at TIMESTAMP,
    email_count INTEGER DEFAULT 0,
    
    -- Business Context
    business_purpose TEXT,
    priority VARCHAR(20) DEFAULT 'medium',
    
    -- Administrative
    added_by VARCHAR(255),
    verified_by VARCHAR(255),
    notes TEXT,
    approval_date TIMESTAMP
);

-- Email processing rules for specific parsing
CREATE TABLE IF NOT EXISTS email_processing_rules (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    trusted_sender_id INTEGER NOT NULL REFERENCES trusted_email_senders(id) ON DELETE CASCADE,
    rule_name VARCHAR(255) NOT NULL,
    rule_description TEXT,
    email_type VARCHAR(100) NOT NULL,
    
    -- Parsing Configuration
    subject_pattern TEXT,
    body_patterns TEXT, -- JSON array
    required_fields TEXT, -- JSON array
    field_mappings TEXT, -- JSON mapping
    
    -- Rule Status
    is_active BOOLEAN DEFAULT true,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,
    
    created_by VARCHAR(255),
    test_results TEXT -- JSON
);

-- Email processing log for audit trail
CREATE TABLE IF NOT EXISTS email_processing_logs (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    incoming_email_id INTEGER NOT NULL REFERENCES incoming_emails(id),
    trusted_sender_id INTEGER REFERENCES trusted_email_senders(id),
    
    processing_status VARCHAR(50),
    processing_result TEXT, -- JSON
    extracted_data TEXT, -- JSON
    error_message TEXT,
    processing_time_ms INTEGER,
    
    action_taken VARCHAR(100),
    impact_description TEXT,
    
    confidence_score DECIMAL(3,2),
    requires_review BOOLEAN DEFAULT false,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP,
    review_notes TEXT
);

-- ============================================================================
-- APPROVAL AND APPLICATION MANAGEMENT
-- ============================================================================

-- Approvals for rental applications and other requests
CREATE TABLE IF NOT EXISTS approvals (
    id SERIAL PRIMARY KEY,
    approval_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    priority VARCHAR(20) DEFAULT 'medium',
    
    -- Applicant Information
    applicant_name VARCHAR(255),
    applicant_email VARCHAR(255),
    property_address TEXT,
    documents TEXT, -- JSON array
    notes TEXT,
    
    -- FUB Integration
    fub_match BOOLEAN DEFAULT false,
    fub_lead_id VARCHAR(100),
    behavioral_score INTEGER DEFAULT 0,
    
    -- Timeline Tracking
    application_date TIMESTAMP,
    approval_date TIMESTAMP,
    rejection_date TIMESTAMP,
    lease_signed_date TIMESTAMP,
    move_in_date TIMESTAMP,
    
    -- Review Process
    reviewed BOOLEAN DEFAULT false,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- FUB INTEGRATION MODELS
-- ============================================================================

-- FUB Leads
CREATE TABLE IF NOT EXISTS fub_leads (
    id SERIAL PRIMARY KEY,
    fub_lead_id VARCHAR(100) UNIQUE NOT NULL,
    fub_person_id VARCHAR(100),
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(50),
    source VARCHAR(100),
    status VARCHAR(50),
    tags TEXT, -- JSON array
    custom_fields TEXT, -- JSON
    last_activity TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Communications
CREATE TABLE IF NOT EXISTS fub_communications (
    id SERIAL PRIMARY KEY,
    fub_lead_id VARCHAR(100) NOT NULL,
    type VARCHAR(50), -- email, sms, call
    subject TEXT,
    body TEXT,
    status VARCHAR(50),
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    opened_at TIMESTAMP,
    clicked_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Tasks
CREATE TABLE IF NOT EXISTS fub_tasks (
    id SERIAL PRIMARY KEY,
    fub_task_id VARCHAR(100) UNIQUE,
    fub_lead_id VARCHAR(100) NOT NULL,
    title VARCHAR(500),
    description TEXT,
    due_date TIMESTAMP,
    status VARCHAR(50),
    created_by VARCHAR(100),
    assigned_to VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Campaigns
CREATE TABLE IF NOT EXISTS fub_campaigns (
    id SERIAL PRIMARY KEY,
    fub_campaign_id VARCHAR(100) UNIQUE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(50),
    type VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Notes
CREATE TABLE IF NOT EXISTS fub_notes (
    id SERIAL PRIMARY KEY,
    fub_note_id VARCHAR(100) UNIQUE,
    fub_lead_id VARCHAR(100) NOT NULL,
    content TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Properties
CREATE TABLE IF NOT EXISTS fub_properties (
    id SERIAL PRIMARY KEY,
    fub_property_id VARCHAR(100) UNIQUE,
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    property_type VARCHAR(100),
    status VARCHAR(50),
    mls_number VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Smart Lists
CREATE TABLE IF NOT EXISTS fub_smart_lists (
    id SERIAL PRIMARY KEY,
    fub_list_id VARCHAR(100) UNIQUE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    conditions TEXT, -- JSON
    lead_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    auto_update BOOLEAN DEFAULT true,
    last_updated TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- FUB Automation Triggers
CREATE TABLE IF NOT EXISTS fub_automation_triggers (
    id SERIAL PRIMARY KEY,
    trigger_name VARCHAR(255) NOT NULL,
    trigger_type VARCHAR(100), -- lead_created, lead_updated, email_opened, etc.
    conditions TEXT, -- JSON
    actions TEXT, -- JSON
    is_active BOOLEAN DEFAULT true,
    trigger_count INTEGER DEFAULT 0,
    last_triggered TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- WORKFLOW AND PIPELINE MANAGEMENT
-- ============================================================================

-- Notification states for iPhone-like behavior
CREATE TABLE IF NOT EXISTS notification_states (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(100) NOT NULL,
    notification_type VARCHAR(100),
    context_id VARCHAR(100),
    state VARCHAR(50) DEFAULT 'unread',
    priority INTEGER DEFAULT 0,
    read_at TIMESTAMP,
    dismissed_at TIMESTAMP,
    action_taken VARCHAR(100),
    metadata TEXT, -- JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System settings for application-wide configuration
CREATE TABLE IF NOT EXISTS system_settings (
    id SERIAL PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type VARCHAR(50) DEFAULT 'string',
    description TEXT,
    is_encrypted BOOLEAN DEFAULT false,
    category VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Closing pipeline for lease workflow tracking
CREATE TABLE IF NOT EXISTS closing_pipelines (
    id SERIAL PRIMARY KEY,
    approval_id INTEGER REFERENCES approvals(id),
    pipeline_stage VARCHAR(100) NOT NULL,
    stage_status VARCHAR(50) DEFAULT 'pending',
    
    -- Lease Process Steps
    lease_sent_date TIMESTAMP,
    lease_signed_date TIMESTAMP,
    deposit_received_date TIMESTAMP,
    first_month_received_date TIMESTAMP,
    keys_ready_date TIMESTAMP,
    move_in_date TIMESTAMP,
    
    -- Administrative
    notes TEXT,
    assigned_to VARCHAR(100),
    estimated_completion TIMESTAMP,
    actual_completion TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Scheduled actions for automation
CREATE TABLE IF NOT EXISTS scheduled_actions (
    id SERIAL PRIMARY KEY,
    action_type VARCHAR(100) NOT NULL,
    target_type VARCHAR(100), -- lead, property, booking, etc.
    target_id VARCHAR(100),
    scheduled_for TIMESTAMP NOT NULL,
    action_data TEXT, -- JSON
    status VARCHAR(50) DEFAULT 'pending',
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    executed_at TIMESTAMP,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Property state manager - single source of truth
CREATE TABLE IF NOT EXISTS property_states (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    mls_id VARCHAR(50),
    
    -- Multi-system status tracking
    har_status VARCHAR(50),
    fub_status VARCHAR(50),
    propertyhub_status VARCHAR(50),
    email_status VARCHAR(50),
    
    -- Availability and booking eligibility
    is_available_for_showing BOOLEAN DEFAULT true,
    booking_eligibility VARCHAR(50) DEFAULT 'eligible',
    eligibility_reason TEXT,
    next_available_date TIMESTAMP,
    
    -- Conflict resolution
    has_conflicts BOOLEAN DEFAULT false,
    conflict_count INTEGER DEFAULT 0,
    conflict_resolution_status VARCHAR(50),
    
    -- Update tracking
    last_har_sync TIMESTAMP,
    last_fub_sync TIMESTAMP,
    last_email_update TIMESTAMP,
    master_updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Property conflicts for data conflict resolution
CREATE TABLE IF NOT EXISTS property_conflicts (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    conflict_type VARCHAR(100) NOT NULL,
    source_system_1 VARCHAR(50),
    source_system_2 VARCHAR(50),
    field_name VARCHAR(100),
    value_1 TEXT,
    value_2 TEXT,
    resolution_strategy VARCHAR(100),
    resolved_value TEXT,
    is_resolved BOOLEAN DEFAULT false,
    resolved_by VARCHAR(100),
    resolved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Property booking eligibility tracking
CREATE TABLE IF NOT EXISTS property_booking_eligibilities (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    
    -- Eligibility status
    is_eligible BOOLEAN DEFAULT true,
    eligibility_reason VARCHAR(200),
    
    -- Restrictions and requirements
    requires_approval BOOLEAN DEFAULT false,
    blackout_dates TEXT, -- JSON array of date ranges
    max_daily_showings INTEGER DEFAULT 5,
    min_notice_hours INTEGER DEFAULT 24,
    
    -- Business rules
    weekend_showings_allowed BOOLEAN DEFAULT true,
    evening_showings_allowed BOOLEAN DEFAULT false,
    group_showings_allowed BOOLEAN DEFAULT true,
    
    -- Status tracking
    last_eligibility_check TIMESTAMP,
    eligibility_updated_by VARCHAR(100),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- LEAD REENGAGEMENT EXTENDED SYSTEM
-- ============================================================================

-- Campaign templates for reusable campaigns
CREATE TABLE IF NOT EXISTS campaign_templates (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    campaign_type VARCHAR(100),
    
    -- Template Configuration
    template_content TEXT, -- JSON structure
    trigger_conditions TEXT, -- JSON
    frequency_rules TEXT, -- JSON
    
    -- Status and Usage
    is_active BOOLEAN DEFAULT true,
    usage_count INTEGER DEFAULT 0,
    last_used TIMESTAMP,
    
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Campaign executions for tracking active campaigns
CREATE TABLE IF NOT EXISTS campaign_executions (
    id SERIAL PRIMARY KEY,
    template_id INTEGER REFERENCES campaign_templates(id),
    campaign_name VARCHAR(255),
    
    -- Execution Details
    target_audience TEXT, -- JSON criteria
    execution_status VARCHAR(50) DEFAULT 'scheduled',
    scheduled_start TIMESTAMP,
    actual_start TIMESTAMP,
    completion_date TIMESTAMP,
    
    -- Performance Metrics
    total_recipients INTEGER DEFAULT 0,
    successful_sends INTEGER DEFAULT 0,
    failed_sends INTEGER DEFAULT 0,
    open_rate DECIMAL(5,2),
    click_rate DECIMAL(5,2),
    response_rate DECIMAL(5,2),
    
    -- Administrative
    executed_by VARCHAR(100),
    error_log TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Reengagement metrics for performance tracking
CREATE TABLE IF NOT EXISTS reengagement_metrics (
    id SERIAL PRIMARY KEY,
    metric_date DATE NOT NULL,
    
    -- Daily Metrics
    leads_contacted INTEGER DEFAULT 0,
    responses_received INTEGER DEFAULT 0,
    reengagement_rate DECIMAL(5,2),
    conversion_rate DECIMAL(5,2),
    
    -- Channel Breakdown
    email_campaigns INTEGER DEFAULT 0,
    sms_campaigns INTEGER DEFAULT 0,
    phone_calls INTEGER DEFAULT 0,
    
    -- Performance Indicators
    average_response_time_hours INTEGER,
    peak_response_hour INTEGER,
    best_performing_channel VARCHAR(50),
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- NOTIFICATION SYSTEM TABLES
-- ============================================================================

-- Property notifications
CREATE TABLE IF NOT EXISTS property_notifications (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    notification_type VARCHAR(100) NOT NULL,
    title VARCHAR(500),
    message TEXT,
    
    -- Recipient Information
    recipient_type VARCHAR(50), -- admin, agent, client, system
    recipient_id VARCHAR(100),
    recipient_email VARCHAR(255),
    
    -- Delivery Configuration
    delivery_method VARCHAR(50), -- email, sms, push, in_app
    priority VARCHAR(20) DEFAULT 'normal',
    schedule_for TIMESTAMP,
    
    -- Status Tracking
    status VARCHAR(50) DEFAULT 'pending',
    sent_at TIMESTAMP,
    delivered_at TIMESTAMP,
    read_at TIMESTAMP,
    
    -- Business Context
    action_required BOOLEAN DEFAULT false,
    action_url TEXT,
    expires_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Property notification logs
CREATE TABLE IF NOT EXISTS property_notification_logs (
    id SERIAL PRIMARY KEY,
    notification_id INTEGER REFERENCES property_notifications(id),
    
    -- Delivery Attempt Information
    attempt_number INTEGER DEFAULT 1,
    delivery_status VARCHAR(50),
    delivery_method VARCHAR(50),
    
    -- Technical Details
    provider VARCHAR(100), -- sendgrid, twilio, etc.
    provider_message_id VARCHAR(255),
    provider_response TEXT,
    
    -- Error Handling
    error_code VARCHAR(50),
    error_message TEXT,
    retry_scheduled_for TIMESTAMP,
    
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notification templates
CREATE TABLE IF NOT EXISTS notification_templates (
    id SERIAL PRIMARY KEY,
    template_name VARCHAR(255) UNIQUE NOT NULL,
    template_type VARCHAR(100),
    
    -- Template Content
    subject_template VARCHAR(500),
    content_template TEXT,
    sms_template TEXT,
    
    -- Template Configuration
    variables TEXT, -- JSON array of available variables
    delivery_methods TEXT, -- JSON array: ["email", "sms", "push"]
    default_method VARCHAR(50),
    
    -- Business Rules
    requires_approval BOOLEAN DEFAULT false,
    auto_send_conditions TEXT, -- JSON
    priority VARCHAR(20) DEFAULT 'normal',
    
    -- Status and Usage
    is_active BOOLEAN DEFAULT true,
    usage_count INTEGER DEFAULT 0,
    last_used TIMESTAMP,
    
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notification statistics
CREATE TABLE IF NOT EXISTS notification_stats (
    id SERIAL PRIMARY KEY,
    stats_date DATE NOT NULL,
    
    -- Volume Metrics
    total_sent INTEGER DEFAULT 0,
    total_delivered INTEGER DEFAULT 0,
    total_failed INTEGER DEFAULT 0,
    
    -- Channel Performance
    email_sent INTEGER DEFAULT 0,
    email_delivered INTEGER DEFAULT 0,
    sms_sent INTEGER DEFAULT 0,
    sms_delivered INTEGER DEFAULT 0,
    
    -- Engagement Metrics
    open_rate DECIMAL(5,2),
    click_rate DECIMAL(5,2),
    response_rate DECIMAL(5,2),
    unsubscribe_rate DECIMAL(5,2),
    
    -- Performance by Type
    property_alerts INTEGER DEFAULT 0,
    booking_confirmations INTEGER DEFAULT 0,
    system_notifications INTEGER DEFAULT 0,
    marketing_messages INTEGER DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- SETUP AND CONFIGURATION TABLES
-- ============================================================================

-- Setup status tracking
CREATE TABLE IF NOT EXISTS setup_statuses (
    id SERIAL PRIMARY KEY,
    setup_step VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    
    -- Step Configuration
    step_order INTEGER,
    is_required BOOLEAN DEFAULT true,
    depends_on TEXT, -- JSON array of prerequisite steps
    
    -- Completion Information
    completed_at TIMESTAMP,
    completed_by VARCHAR(100),
    completion_data TEXT, -- JSON
    
    -- Error Handling
    error_message TEXT,
    retry_count INTEGER DEFAULT 0,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Setup configurations
CREATE TABLE IF NOT EXISTS setup_configurations (
    id SERIAL PRIMARY KEY,
    config_section VARCHAR(100) NOT NULL,
    config_key VARCHAR(100) NOT NULL,
    config_value TEXT,
    
    -- Configuration Metadata
    value_type VARCHAR(50) DEFAULT 'string',
    is_required BOOLEAN DEFAULT false,
    is_sensitive BOOLEAN DEFAULT false,
    validation_rules TEXT, -- JSON
    
    -- Help and Documentation
    display_name VARCHAR(255),
    description TEXT,
    help_text TEXT,
    example_value TEXT,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE(config_section, config_key)
);

-- Admin setup tracking
CREATE TABLE IF NOT EXISTS admin_setups (
    id SERIAL PRIMARY KEY,
    admin_user_id VARCHAR(50) REFERENCES admin_users(id),
    
    -- Setup Progress
    setup_stage VARCHAR(100),
    setup_progress INTEGER DEFAULT 0, -- percentage
    current_step VARCHAR(100),
    
    -- Configuration Choices
    setup_configuration TEXT, -- JSON of choices made
    feature_selections TEXT, -- JSON of enabled features
    
    -- Completion Information
    is_complete BOOLEAN DEFAULT false,
    completed_at TIMESTAMP,
    setup_duration_minutes INTEGER,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- HAR MARKET DATA AND EXTERNAL INTEGRATIONS
-- ============================================================================

-- HAR Market Data table
CREATE TABLE IF NOT EXISTS har_market_data (
    id SERIAL PRIMARY KEY,
    report_type VARCHAR(100) NOT NULL,
    title TEXT NOT NULL,
    url TEXT UNIQUE NOT NULL,
    publish_date TIMESTAMP NOT NULL,
    content TEXT,
    summary TEXT,
    key_metrics JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'active',
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- HAR Scraping logs table
CREATE TABLE IF NOT EXISTS har_scrape_logs (
    id SERIAL PRIMARY KEY,
    scrape_type VARCHAR(100) NOT NULL,
    url TEXT NOT NULL,
    status VARCHAR(50) NOT NULL,
    items_found INTEGER DEFAULT 0,
    items_new INTEGER DEFAULT 0,
    items_updated INTEGER DEFAULT 0,
    error_message TEXT,
    duration INTEGER DEFAULT 0, -- in milliseconds
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Webhook events for tracking all incoming webhooks
CREATE TABLE IF NOT EXISTS webhook_events (
    id SERIAL PRIMARY KEY,
    source VARCHAR(50) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload TEXT,
    headers TEXT,
    signature VARCHAR(255),
    processed_at TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    error_msg TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- AUTOMATION AND COMMUNICATION TABLES
-- ============================================================================

-- Automation rules for SMS/Email automation
CREATE TABLE IF NOT EXISTS automation_rules (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    trigger_type VARCHAR(100) NOT NULL,
    conditions JSONB DEFAULT '{}',
    message_type VARCHAR(50) NOT NULL,
    template TEXT,
    delay_hours INTEGER DEFAULT 0,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Automation executions for tracking automation runs
CREATE TABLE IF NOT EXISTS automation_executions (
    id SERIAL PRIMARY KEY,
    rule_id INTEGER REFERENCES automation_rules(id),
    contact_id VARCHAR(100) NOT NULL,
    trigger_data JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'pending',
    sent_at TIMESTAMP,
    error_msg TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Calendar events for Follow Up Boss integration
CREATE TABLE IF NOT EXISTS calendar_events (
    id SERIAL PRIMARY KEY,
    fub_event_id VARCHAR(100) UNIQUE,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    location VARCHAR(500),
    contact_id VARCHAR(100),
    property_id VARCHAR(100),
    event_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- COMPREHENSIVE INDEXES FOR PERFORMANCE
-- ============================================================================

-- Properties indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_mls_id ON properties(mls_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_city ON properties(city);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_price ON properties(price);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_listing_type ON properties(listing_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_updated_at ON properties(updated_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_created_at ON properties(created_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_city_status ON properties(city, status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_status_price ON properties(status, price);

-- Property photos indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id ON property_photos(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_mls_id ON property_photos(mls_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_file_hash ON property_photos(file_hash);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id_active ON property_photos(property_id, is_active);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id_primary ON property_photos(property_id, is_primary, is_active);

-- Admin users indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_admin_users_email ON admin_users(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_admin_users_username ON admin_users(username);

-- Leads indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_fub_id ON leads(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_status ON leads(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_source ON leads(source);

-- Bookings indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_property_id ON bookings(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_fub_lead_id ON bookings(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_showing_date ON bookings(showing_date);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_reference_number ON bookings(reference_number);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);

-- Contacts indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_created_at ON contacts(created_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_status ON contacts(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_fub_lead_id ON contacts(fub_lead_id);

-- Pre-listing indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pre_listing_items_status ON pre_listing_items(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pre_listing_items_address ON pre_listing_items(address);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pre_listing_items_created_at ON pre_listing_items(created_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_pre_listing_items_target_date ON pre_listing_items(target_listing_date);

-- Email processing indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incoming_emails_from_email ON incoming_emails(from_email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incoming_emails_processing_status ON incoming_emails(processing_status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incoming_emails_email_type ON incoming_emails(email_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_incoming_emails_received_at ON incoming_emails(received_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_email ON trusted_email_senders(sender_email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_type ON trusted_email_senders(email_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_active ON trusted_email_senders(is_active);

-- Approval indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_status ON approvals(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_type ON approvals(approval_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_fub_match ON approvals(fub_match);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_applicant_email ON approvals(applicant_email);

-- FUB integration indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_fub_leads_fub_lead_id ON fub_leads(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_fub_communications_fub_lead_id ON fub_communications(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_fub_tasks_fub_lead_id ON fub_tasks(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_fub_tasks_due_date ON fub_tasks(due_date);

-- Workflow indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_closing_pipelines_approval_id ON closing_pipelines(approval_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_closing_pipelines_stage ON closing_pipelines(pipeline_stage);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_scheduled_actions_scheduled_for ON scheduled_actions(scheduled_for);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_scheduled_actions_status ON scheduled_actions(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_states_property_id ON property_states(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_states_mls_id ON property_states(mls_id);

-- Notification indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_notification_states_user_id ON notification_states(user_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_notifications_property_id ON property_notifications(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_notifications_status ON property_notifications(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_notifications_schedule_for ON property_notifications(schedule_for);

-- HAR Market Data indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_report_type ON har_market_data(report_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_publish_date ON har_market_data(publish_date DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_status ON har_market_data(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_scraped_at ON har_market_data(scraped_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_url_hash ON har_market_data USING HASH(url);

-- HAR Scrape logs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_scrape_type ON har_scrape_logs(scrape_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_status ON har_scrape_logs(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_scraped_at ON har_scrape_logs(scraped_at DESC);

-- Webhook events indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_source ON webhook_events(source);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_event_type ON webhook_events(event_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_status ON webhook_events(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_created_at ON webhook_events(created_at DESC);

-- Automation indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_rules_trigger_type ON automation_rules(trigger_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_rules_active ON automation_rules(active);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_rule_id ON automation_executions(rule_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_contact_id ON automation_executions(contact_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_status ON automation_executions(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_created_at ON automation_executions(created_at DESC);

-- Calendar events indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_fub_event_id ON calendar_events(fub_event_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_start_time ON calendar_events(start_time);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_contact_id ON calendar_events(contact_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_event_type ON calendar_events(event_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_status ON calendar_events(status);

-- System settings indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_system_settings_key ON system_settings(setting_key);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_system_settings_category ON system_settings(category);

-- Lead reengagement indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_email ON lead_reengagement(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_last_activity ON lead_reengagement(last_activity);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_campaign_status ON lead_reengagement(campaign_status);

-- ============================================================================
-- SAMPLE DATA INSERTION
-- ============================================================================

-- Sample properties (Christopher Gross portfolio)
INSERT INTO properties (
    mls_id, address, city, state, zip_code, price, description,
    listing_type, status, listing_agent, listing_office,
    bedrooms, bathrooms, square_feet, property_type, source
) VALUES 
(
    '20420686',
    '123 Main Street',
    'Houston',
    'TX',
    '77001',
    259000.00,
    'Beautiful contemporary home with modern amenities and great location.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    3,
    2.0,
    1500,
    'Contemporary/Modern',
    'HAR'
),
(
    '8352969',
    '456 Oak Avenue',
    'Sugar Land',
    'TX',
    '77478',
    434989.00,
    'Stunning traditional home in desirable neighborhood.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    4,
    3.0,
    2200,
    'Traditional',
    'HAR'
),
(
    '45780172',
    '789 Pine Street',
    'Katy',
    'TX',
    '77494',
    165000.00,
    'Charming starter home with great potential.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    2,
    1.5,
    1200,
    'Traditional',
    'HAR'
) ON CONFLICT (mls_id) DO NOTHING;

-- Essential system settings
INSERT INTO system_settings (setting_key, setting_value, setting_type, description, category) VALUES
('platform_name', 'PropertyHub', 'string', 'Platform display name', 'general'),
('primary_market', 'Houston, TX', 'string', 'Primary market location', 'general'),
('business_phone', '(713) 555-0123', 'string', 'Business phone number', 'contact'),
('business_email', 'info@propertyhub.com', 'string', 'Business email address', 'contact'),
('har_integration_enabled', 'true', 'boolean', 'HAR Integration status', 'integrations'),
('fub_integration_enabled', 'true', 'boolean', 'Follow Up Boss Integration status', 'integrations'),
('trec_compliance_enabled', 'true', 'boolean', 'TREC Compliance monitoring status', 'compliance'),
('email_automation_enabled', 'true', 'boolean', 'Email automation status', 'automation'),
('max_daily_showings', '5', 'integer', 'Maximum showings per property per day', 'booking'),
('min_notice_hours', '24', 'integer', 'Minimum notice required for bookings', 'booking')
ON CONFLICT (setting_key) DO NOTHING;

-- Default notification templates
INSERT INTO notification_templates (template_name, template_type, subject_template, content_template, delivery_methods, is_active) VALUES
('booking_confirmation', 'booking', 'Showing Confirmed - {{property_address}}', 'Your showing for {{property_address}} is confirmed for {{showing_date}}.', '["email", "sms"]', true),
('pre_listing_overdue', 'pre_listing', 'Pre-Listing Overdue: {{property_address}}', 'The pre-listing item for {{property_address}} is overdue. Please review.', '["email"]', true),
('application_received', 'application', 'Application Received - {{property_address}}', 'New application received for {{property_address}} from {{applicant_name}}.', '["email"]', true)
ON CONFLICT (template_name) DO NOTHING;

-- ============================================================================
-- PERMISSIONS AND GRANTS
-- ============================================================================

-- Grant permissions to ubuntu user
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ubuntu;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ubuntu;

-- Create database functions for common operations
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Add updated_at triggers to relevant tables
CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON properties
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_bookings_updated_at BEFORE UPDATE ON bookings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_leads_updated_at BEFORE UPDATE ON leads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_approvals_updated_at BEFORE UPDATE ON approvals
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_pre_listing_items_updated_at BEFORE UPDATE ON pre_listing_items
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- ============================================================================
-- APPLICATION WORKFLOW TABLES (Christopher's Specific Design)
-- ============================================================================

-- Property application groups - manages applications by property
CREATE TABLE IF NOT EXISTS property_application_groups (
    id SERIAL PRIMARY KEY,
    property_id INTEGER NOT NULL,
    property_address TEXT NOT NULL,
    total_applications INTEGER DEFAULT 0,
    active_applications INTEGER DEFAULT 0,
    applications_created INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT unique_property_address UNIQUE (property_address)
);

-- Application numbers - Application 1, Application 2, etc.
CREATE TABLE IF NOT EXISTS application_numbers (
    id SERIAL PRIMARY KEY,
    property_application_group_id INTEGER NOT NULL REFERENCES property_application_groups(id) ON DELETE CASCADE,
    application_number INTEGER NOT NULL,
    application_name VARCHAR(255),
    status VARCHAR(50) DEFAULT 'submitted',
    status_updated_at TIMESTAMP WITH TIME ZONE,
    status_updated_by VARCHAR(255),
    assigned_agent_name VARCHAR(255),
    assigned_agent_phone VARCHAR(50),
    assigned_agent_email VARCHAR(255),
    agent_assigned_at TIMESTAMP WITH TIME ZONE,
    application_notes TEXT,
    internal_notes TEXT,
    applicant_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE,
    
    CONSTRAINT unique_app_number_per_property UNIQUE (property_application_group_id, application_number),
    CONSTRAINT valid_application_status CHECK (status IN ('submitted', 'review', 'further_review', 'rental_history_received', 'approved', 'denied', 'backup', 'cancelled'))
);

-- Application applicants - individual people from Buildium
CREATE TABLE IF NOT EXISTS application_applicants (
    id SERIAL PRIMARY KEY,
    application_number_id INTEGER REFERENCES application_numbers(id) ON DELETE SET NULL,
    applicant_name VARCHAR(255) NOT NULL,
    applicant_email VARCHAR(255) NOT NULL,
    applicant_phone VARCHAR(50),
    fub_lead_id VARCHAR(100),
    fub_match BOOLEAN DEFAULT false,
    match_score DECIMAL(3,2) DEFAULT 0.00,
    application_date TIMESTAMP WITH TIME ZONE NOT NULL,
    source_email VARCHAR(255),
    application_data JSONB,
    applicant_notes TEXT,
    credit_score INTEGER,
    income DECIMAL(12,2),
    employment_status VARCHAR(100),
    rental_history TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- Application status audit log
CREATE TABLE IF NOT EXISTS application_status_logs (
    id SERIAL PRIMARY KEY,
    application_number_id INTEGER NOT NULL REFERENCES application_numbers(id) ON DELETE CASCADE,
    previous_status VARCHAR(50),
    new_status VARCHAR(50),
    changed_by VARCHAR(255),
    change_reason TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Application workflow indexes
CREATE INDEX IF NOT EXISTS idx_property_application_groups_property_id ON property_application_groups(property_id);
CREATE INDEX IF NOT EXISTS idx_application_numbers_property_group ON application_numbers(property_application_group_id);
CREATE INDEX IF NOT EXISTS idx_application_numbers_status ON application_numbers(status);
CREATE INDEX IF NOT EXISTS idx_application_applicants_number ON application_applicants(application_number_id);
CREATE INDEX IF NOT EXISTS idx_application_applicants_email ON application_applicants(applicant_email);
CREATE INDEX IF NOT EXISTS idx_application_applicants_fub ON application_applicants(fub_lead_id);
CREATE INDEX IF NOT EXISTS idx_application_status_logs_number ON application_status_logs(application_number_id);

-- Application workflow comments
COMMENT ON TABLE property_application_groups IS 'Groups applications by property for Christopher''s business model';
COMMENT ON TABLE application_numbers IS 'Application slots (1,2,3,etc) for drag-and-drop assignment';
COMMENT ON TABLE application_applicants IS 'Individual applicants from Buildium - can be unassigned or assigned';
COMMENT ON COLUMN application_applicants.application_number_id IS 'NULL = unassigned (sidebar), value = assigned to Application X';

-- ============================================================================
-- SCHEMA VALIDATION COMMENTS
-- ============================================================================

-- This comprehensive schema includes:
-- ✓ All core PropertyHub tables
-- ✓ All email sender management tables  
-- ✓ All pre-listing workflow tables
-- ✓ All FUB integration tables
-- ✓ All workflow and pipeline tables
-- ✓ All notification system tables
-- ✓ All lead reengagement tables
-- ✓ All application workflow tables (Christopher's design)
-- ✓ All setup and configuration tables
-- ✓ Complete indexing for performance
-- ✓ Foreign key constraints
-- ✓ Triggers for timestamp management
-- ✓ Sample data for immediate functionality
-- ✓ Proper permissions and grants

-- Total tables: 44+ (covers all models including new application workflow)
-- This schema provides complete database foundation for PropertyHub deployment