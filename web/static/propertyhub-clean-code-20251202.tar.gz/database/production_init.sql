-- PropertyHub Production Database Schema
-- Complete initialization script for fresh production deployment

-- Create system_settings table (central configuration store)
CREATE TABLE IF NOT EXISTS system_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(255) UNIQUE NOT NULL,
    value TEXT,
    description TEXT,
    category VARCHAR(100) DEFAULT 'general',
    is_encrypted BOOLEAN DEFAULT FALSE,
    is_secret BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_system_settings_key ON system_settings(key);
CREATE INDEX IF NOT EXISTS idx_system_settings_category ON system_settings(category);

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT DEFAULT 'admin',
    active BOOLEAN DEFAULT true,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create properties table
CREATE TABLE IF NOT EXISTS properties (
    id SERIAL PRIMARY KEY,
    mls_id TEXT UNIQUE,
    address TEXT NOT NULL,
    city TEXT DEFAULT 'Houston',
    state TEXT DEFAULT 'TX',
    zip_code TEXT,
    bedrooms INTEGER,
    bathrooms REAL,
    square_feet INTEGER,
    property_type TEXT,
    price DECIMAL(12,2),
    listing_type TEXT DEFAULT 'For Sale',
    status TEXT DEFAULT 'active',
    description TEXT,
    images TEXT[],
    featured_image TEXT,
    listing_agent TEXT DEFAULT 'Christopher Gross',
    listing_agent_id TEXT,
    listing_office TEXT DEFAULT 'Landlords of Texas, LLC',
    property_features TEXT,
    source TEXT DEFAULT 'PropertyHub',
    har_url TEXT,
    view_count INTEGER DEFAULT 0,
    days_on_market INTEGER,
    scraped_at TIMESTAMP,
    year_built INTEGER,
    management_company TEXT,
    date_added TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);

-- Create properties indexes
CREATE INDEX IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_city ON properties(city);
CREATE INDEX IF NOT EXISTS idx_properties_price ON properties(price);
CREATE INDEX IF NOT EXISTS idx_properties_property_type ON properties(property_type);
CREATE INDEX IF NOT EXISTS idx_properties_mls_id ON properties(mls_id);

-- Create bookings table  
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    reference_number TEXT UNIQUE NOT NULL,
    property_id INTEGER REFERENCES properties(id),
    property_address TEXT,
    fub_lead_id TEXT NOT NULL,
    email TEXT,
    name TEXT,
    fub_synced BOOLEAN DEFAULT FALSE,
    phone TEXT,
    interest_level TEXT,
    showing_date TIMESTAMP NOT NULL,
    duration_minutes INTEGER DEFAULT 30,
    status TEXT DEFAULT 'scheduled',
    notes TEXT,
    showing_type TEXT DEFAULT 'in-person',
    attendee_count INTEGER DEFAULT 1,
    special_requests TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create bookings indexes
CREATE INDEX IF NOT EXISTS idx_bookings_showing_date ON bookings(showing_date);
CREATE INDEX IF NOT EXISTS idx_bookings_property_id ON bookings(property_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_bookings_reference_number ON bookings(reference_number);

-- Create encryption_keys table (for field-level encryption)
CREATE TABLE IF NOT EXISTS encryption_keys (
    id SERIAL PRIMARY KEY,
    key_id TEXT UNIQUE NOT NULL,
    key_hash TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    rotated_at TIMESTAMP,
    description TEXT
);

-- Create audit_logs table (for security and compliance)
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    user_id TEXT,
    action TEXT NOT NULL,
    table_name TEXT,
    record_id TEXT,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    session_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create audit_logs indexes
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action ON audit_logs(action);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_logs_table_name ON audit_logs(table_name);

-- Grant permissions (adjust user as needed)
-- GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO propertyhub_user;
-- GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO propertyhub_user;

-- Insert essential system settings
INSERT INTO system_settings (key, value, description, category, is_secret) VALUES 
    ('SETUP_COMPLETE', 'true', 'Initial system setup completed', 'system', FALSE),
    ('ADMIN_LOGIN_ENABLED', 'true', 'Enable admin login functionality', 'security', FALSE),
    ('MFA_REQUIRED', 'true', 'Require multi-factor authentication for admin users', 'security', FALSE),
    ('TREC_COMPLIANCE_ENABLED', 'true', 'Enable TREC compliance monitoring', 'compliance', FALSE),
    ('BOOKING_SYSTEM_ENABLED', 'true', 'Enable property booking system', 'features', FALSE),
    ('ANALYTICS_ENABLED', 'true', 'Enable analytics tracking', 'features', FALSE),
    ('CONTACT_FORM_ENABLED', 'true', 'Enable contact form submissions', 'features', FALSE),
    ('EMAIL_AUTOMATION_ENABLED', 'true', 'Enable automated email workflows', 'features', FALSE),
    ('PHOTO_UPLOADS_ENABLED', 'true', 'Enable property photo uploads', 'features', FALSE),
    ('HAR_INTEGRATION_ENABLED', 'false', 'Enable HAR MLS integration (requires API key)', 'integrations', FALSE),
    ('FUB_INTEGRATION_ENABLED', 'false', 'Enable FUB CRM integration (requires API key)', 'integrations', FALSE),
    
    -- Business Information
    ('BUSINESS_NAME', 'PropertyHub Real Estate', 'Business name for branding and legal', 'business', FALSE),
    ('BUSINESS_PHONE', '(555) 123-4567', 'Main business phone number', 'business', FALSE),
    ('BUSINESS_EMAIL', 'info@propertyhub.com', 'Main business email address', 'business', FALSE),
    ('BUSINESS_ADDRESS', '123 Main Street, Houston, TX 77001', 'Business address for legal compliance', 'business', FALSE),
    ('TREC_LICENSE', 'TX-LICENSE-123456', 'TREC license number for compliance', 'business', FALSE),
    
    -- System Configuration
    ('DATABASE_MAX_CONNS', '25', 'Maximum database connections', 'database', FALSE),
    ('DATABASE_TIMEOUT_SECONDS', '30', 'Database connection timeout', 'database', FALSE),
    ('SESSION_TIMEOUT_MINUTES', '60', 'User session timeout in minutes', 'security', FALSE),
    ('RATE_LIMIT_REQUESTS_PER_MINUTE', '100', 'API rate limit per minute', 'security', FALSE),
    ('AUDIT_LOG_RETENTION_DAYS', '365', 'Audit log retention period', 'compliance', FALSE),
    
    -- Email Configuration
    ('SMTP_HOST', 'smtp.yourdomain.com', 'SMTP server hostname', 'email', FALSE),
    ('SMTP_PORT', '587', 'SMTP server port', 'email', FALSE),
    
    -- Redis Configuration
    ('REDIS_URL', 'localhost:6379', 'Redis server URL', 'cache', FALSE),
    ('REDIS_DB', '0', 'Redis database number', 'cache', FALSE)

ON CONFLICT (key) DO UPDATE SET
    value = EXCLUDED.value,
    description = EXCLUDED.description,
    category = EXCLUDED.category,
    updated_at = CURRENT_TIMESTAMP;

-- Note: Secret settings (API keys, passwords, encryption keys) should be 
-- added separately using the db_config_manager.sh script for security