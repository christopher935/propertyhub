-- APPLICATION WORKFLOW MIGRATION
-- Creates tables for Christopher's specific application workflow system
-- Applicants drag-and-drop between Application 1, Application 2, Application 3, etc.

BEGIN;

-- Create property_application_groups table
CREATE TABLE property_application_groups (
    id SERIAL PRIMARY KEY,
    property_id INTEGER NOT NULL,
    property_address TEXT NOT NULL,
    total_applications INTEGER DEFAULT 0,
    active_applications INTEGER DEFAULT 0,
    applications_created INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create application_numbers table
CREATE TABLE application_numbers (
    id SERIAL PRIMARY KEY,
    property_application_group_id INTEGER NOT NULL REFERENCES property_application_groups(id) ON DELETE CASCADE,
    application_number INTEGER NOT NULL,
    application_name VARCHAR(255),
    status VARCHAR(50) DEFAULT 'submitted',
    status_updated_at TIMESTAMP WITH TIME ZONE,
    status_updated_by VARCHAR(255),
    assigned_agent_name VARCHAR(255),
    assigned_agent_phone VARCHAR(50),
    assigned_agent_email VARCHAR(255),
    agent_assigned_at TIMESTAMP WITH TIME ZONE,
    application_notes TEXT,
    internal_notes TEXT,
    applicant_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- Create application_applicants table
CREATE TABLE application_applicants (
    id SERIAL PRIMARY KEY,
    application_number_id INTEGER REFERENCES application_numbers(id) ON DELETE SET NULL,
    applicant_name VARCHAR(255) NOT NULL,
    applicant_email VARCHAR(255) NOT NULL,
    applicant_phone VARCHAR(50),
    fub_lead_id VARCHAR(100),
    fub_match BOOLEAN DEFAULT false,
    match_score DECIMAL(3,2) DEFAULT 0.00,
    application_date TIMESTAMP WITH TIME ZONE NOT NULL,
    source_email VARCHAR(255),
    application_data JSONB,
    applicant_notes TEXT,
    credit_score INTEGER,
    income DECIMAL(12,2),
    employment_status VARCHAR(100),
    rental_history TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE
);

-- Create application_status_logs table (audit trail)
CREATE TABLE application_status_logs (
    id SERIAL PRIMARY KEY,
    application_number_id INTEGER NOT NULL REFERENCES application_numbers(id) ON DELETE CASCADE,
    previous_status VARCHAR(50),
    new_status VARCHAR(50),
    changed_by VARCHAR(255),
    change_reason TEXT,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX idx_property_application_groups_property_id ON property_application_groups(property_id);
CREATE INDEX idx_property_application_groups_address ON property_application_groups(property_address);

CREATE INDEX idx_application_numbers_property_group ON application_numbers(property_application_group_id);
CREATE INDEX idx_application_numbers_status ON application_numbers(status);
CREATE INDEX idx_application_numbers_deleted ON application_numbers(deleted_at);

CREATE INDEX idx_application_applicants_application_number ON application_applicants(application_number_id);
CREATE INDEX idx_application_applicants_email ON application_applicants(applicant_email);
CREATE INDEX idx_application_applicants_fub_lead ON application_applicants(fub_lead_id);
CREATE INDEX idx_application_applicants_application_date ON application_applicants(application_date);
CREATE INDEX idx_application_applicants_deleted ON application_applicants(deleted_at);

CREATE INDEX idx_application_status_logs_application_number ON application_status_logs(application_number_id);
CREATE INDEX idx_application_status_logs_created_at ON application_status_logs(created_at);

-- Create constraints
ALTER TABLE property_application_groups ADD CONSTRAINT unique_property_address UNIQUE (property_address);
ALTER TABLE application_numbers ADD CONSTRAINT unique_app_number_per_property UNIQUE (property_application_group_id, application_number);

-- Add status check constraints
ALTER TABLE application_numbers ADD CONSTRAINT valid_application_status 
    CHECK (status IN ('submitted', 'review', 'further_review', 'rental_history_received', 'approved', 'denied', 'backup', 'cancelled'));

-- Create function to auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for auto-updating timestamps
CREATE TRIGGER update_property_application_groups_updated_at BEFORE UPDATE ON property_application_groups 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_application_numbers_updated_at BEFORE UPDATE ON application_numbers 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_application_applicants_updated_at BEFORE UPDATE ON application_applicants 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Migrate Terry -> Broker field names in pre_listing_items if table exists
DO $$
BEGIN
    -- Check if pre_listing_items table exists and has terry columns
    IF EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'pre_listing_items' AND column_name = 'terry_email_date') THEN
        ALTER TABLE pre_listing_items RENAME COLUMN terry_email_date TO broker_email_date;
        ALTER TABLE pre_listing_items RENAME COLUMN terry_email_subject TO broker_email_subject;
        ALTER TABLE pre_listing_items RENAME COLUMN terry_email_content TO broker_email_content;
        
        -- Update any existing data that references terry_alert
        UPDATE incoming_emails SET email_type = 'broker_alert' WHERE email_type = 'terry_alert';
        UPDATE trusted_email_senders SET email_type = 'broker_alert' WHERE email_type = 'terry_alert';
    END IF;
END
$$;

COMMIT;

-- Add helpful comments
COMMENT ON TABLE property_application_groups IS 'Groups applications by property - Christopher''s business model allows multiple applications per property';
COMMENT ON TABLE application_numbers IS 'Application slots (1,2,3,etc) that applicants can be dragged into';
COMMENT ON TABLE application_applicants IS 'Individual applicants from Buildium notifications, can be unassigned or assigned to application numbers';
COMMENT ON TABLE application_status_logs IS 'Audit trail for all application status changes';

COMMENT ON COLUMN application_applicants.application_number_id IS 'NULL means unassigned applicant (shows in sidebar), set value means assigned to Application X';
COMMENT ON COLUMN application_numbers.assigned_agent_name IS 'External agent assigned to this application - not system users';
COMMENT ON COLUMN application_applicants.fub_match IS 'Whether this applicant was matched to existing FUB lead';