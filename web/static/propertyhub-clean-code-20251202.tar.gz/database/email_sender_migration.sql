-- Email Sender Management System Tables
-- These tables must be added to database/schema.sql for deployment

-- Trusted Email Senders table
CREATE TABLE IF NOT EXISTS trusted_email_senders (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Sender Information
    sender_email VARCHAR(255) UNIQUE NOT NULL,
    sender_name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    contact_person VARCHAR(255),

    -- Email Processing Configuration
    email_type VARCHAR(100) NOT NULL, -- application_notification, pre_listing_alert, lease_update, vendor_completion, terry_alert
    processing_mode VARCHAR(50) DEFAULT 'automatic', -- automatic, manual_review, disabled
    parsing_template TEXT, -- JSON template for extracting data
    
    -- Status and Control
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    last_email_at TIMESTAMP,
    email_count INTEGER DEFAULT 0,
    
    -- Business Context
    business_purpose TEXT, -- Description of what emails from this sender accomplish
    priority VARCHAR(20) DEFAULT 'medium', -- high, medium, low (affects processing speed)
    
    -- Administrative
    added_by VARCHAR(255),
    verified_by VARCHAR(255),
    notes TEXT,
    approval_date TIMESTAMP
);

-- Email Processing Rules table
CREATE TABLE IF NOT EXISTS email_processing_rules (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Rule Information
    trusted_sender_id INTEGER NOT NULL REFERENCES trusted_email_senders(id),
    rule_name VARCHAR(255) NOT NULL,
    rule_description TEXT,
    email_type VARCHAR(100) NOT NULL,
    
    -- Parsing Configuration
    subject_pattern TEXT, -- Regex or keywords to match subject lines
    body_patterns TEXT, -- JSON array of patterns to extract data
    required_fields TEXT, -- JSON array of required extracted fields
    
    -- Extraction Mapping
    field_mappings TEXT, -- JSON mapping of extracted fields to PropertyHub fields
    
    -- Rule Status
    is_active BOOLEAN DEFAULT true,
    success_count INTEGER DEFAULT 0,
    failure_count INTEGER DEFAULT 0,
    last_used_at TIMESTAMP,
    
    -- Administrative
    created_by VARCHAR(255),
    test_results TEXT -- JSON of test parsing results
);

-- Email Processing Log table
CREATE TABLE IF NOT EXISTS email_processing_logs (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,

    -- Email Reference
    incoming_email_id INTEGER NOT NULL,
    trusted_sender_id INTEGER REFERENCES trusted_email_senders(id),
    
    -- Processing Results
    processing_status VARCHAR(50), -- success, failed, sender_not_trusted, parsing_failed
    processing_result TEXT, -- JSON result of processing
    extracted_data TEXT, -- JSON of successfully extracted fields
    error_message TEXT,
    processing_time_ms INTEGER,
    
    -- Business Impact
    action_taken VARCHAR(100), -- pre_listing_created, application_matched, status_updated, manual_review_needed
    impact_description TEXT,
    
    -- Quality Metrics
    confidence_score DECIMAL(3,2), -- 0.0-1.0 confidence in parsing accuracy
    requires_review BOOLEAN DEFAULT false,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP,
    review_notes TEXT
);

-- Missing Core Tables (Models exist but tables missing from schema.sql)

-- Leads table
CREATE TABLE IF NOT EXISTS leads (
    id SERIAL PRIMARY KEY,
    first_name VARCHAR(255) NOT NULL,
    last_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    fub_lead_id VARCHAR(100) UNIQUE,
    source VARCHAR(100) DEFAULT 'Website',
    status VARCHAR(50) DEFAULT 'new',
    tags TEXT, -- JSON array
    custom_fields TEXT, -- JSON
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Approvals table (for rental applications)
CREATE TABLE IF NOT EXISTS approvals (
    id SERIAL PRIMARY KEY,
    approval_type VARCHAR(100) NOT NULL, -- rental_application, property_listing, etc.
    status VARCHAR(50) DEFAULT 'pending', -- pending, approved, rejected, under_review
    priority VARCHAR(20) DEFAULT 'medium', -- low, medium, high
    applicant_name VARCHAR(255),
    applicant_email VARCHAR(255),
    property_address TEXT,
    documents TEXT, -- JSON array
    notes TEXT,
    
    -- Additional fields for application intelligence
    fub_match BOOLEAN DEFAULT false,
    fub_lead_id VARCHAR(100),
    behavioral_score INTEGER DEFAULT 0,
    application_date TIMESTAMP,
    approval_date TIMESTAMP,
    rejection_date TIMESTAMP,
    lease_signed_date TIMESTAMP,
    move_in_date TIMESTAMP,
    reviewed BOOLEAN DEFAULT false,
    reviewed_by VARCHAR(255),
    reviewed_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add foreign key constraint for email processing logs
ALTER TABLE email_processing_logs 
ADD CONSTRAINT fk_email_processing_logs_incoming_email 
FOREIGN KEY (incoming_email_id) REFERENCES incoming_emails(id);

-- Performance indexes for email sender management
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_email ON trusted_email_senders(sender_email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_type ON trusted_email_senders(email_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_trusted_email_senders_active ON trusted_email_senders(is_active);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_email_processing_rules_sender ON email_processing_rules(trusted_sender_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_email_processing_logs_status ON email_processing_logs(processing_status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_fub_id ON leads(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_leads_email ON leads(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_status ON approvals(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_type ON approvals(approval_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_approvals_fub_match ON approvals(fub_match);

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ubuntu;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ubuntu;