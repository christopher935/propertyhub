-- PropertyHub Secret Configuration Setup
-- Run this after production_init.sql to add secret settings
-- These are separated for security (don't commit to version control)

-- Generate and insert secret settings
-- Note: Run this script through the db_config_manager.sh for proper handling

-- JWT and Encryption (CRITICAL - generate unique values)
INSERT INTO system_settings (key, value, description, category, is_secret) VALUES 
    ('JWT_SECRET', 'GENERATE_UNIQUE_44_CHAR_JWT_SECRET_HERE', 'JSON Web Token secret for authentication', 'security', TRUE),
    ('ENCRYPTION_KEY', 'GENERATE_UNIQUE_44_CHAR_ENCRYPTION_KEY_HERE', 'Master encryption key for sensitive data', 'security', TRUE)
ON CONFLICT (key) DO NOTHING; -- Don't overwrite existing secrets

-- External Service API Keys (Update with your actual keys)
INSERT INTO system_settings (key, value, description, category, is_secret) VALUES 
    ('FUB_API_KEY', 'your_followup_boss_api_key_here', 'FollowUp Boss CRM API key', 'integrations', TRUE),
    ('HAR_API_KEY', 'your_har_mls_api_key_here', 'Houston Association of Realtors API key', 'integrations', TRUE),
    ('SCRAPER_API_KEY', 'your_scraper_api_key_here', 'Property data scraper API key', 'integrations', TRUE),
    
    -- Twilio SMS/Voice
    ('TWILIO_ACCOUNT_SID', 'your_twilio_account_sid_here', 'Twilio account SID for SMS/voice', 'integrations', TRUE),
    ('TWILIO_AUTH_TOKEN', 'your_twilio_auth_token_here', 'Twilio authentication token', 'integrations', TRUE),
    ('TWILIO_PHONE_NUMBER', '+15551234567', 'Twilio phone number for notifications', 'integrations', FALSE),
    
    -- Email Credentials
    ('SMTP_USERNAME', 'noreply@yourdomain.com', 'SMTP authentication username', 'email', FALSE),
    ('SMTP_PASSWORD', 'your_smtp_password_here', 'SMTP authentication password', 'email', TRUE),
    
    -- Redis Authentication
    ('REDIS_PASSWORD', 'your_redis_password_here', 'Redis server authentication password', 'cache', TRUE)

ON CONFLICT (key) DO UPDATE SET
    updated_at = CURRENT_TIMESTAMP;

-- Security commands to generate actual secrets:
-- 
-- For JWT_SECRET:
-- UPDATE system_settings SET value = encode(gen_random_bytes(32), 'base64') WHERE key = 'JWT_SECRET';
-- 
-- For ENCRYPTION_KEY:  
-- UPDATE system_settings SET value = encode(gen_random_bytes(32), 'base64') WHERE key = 'ENCRYPTION_KEY';

-- Verification query:
-- SELECT key, 
--        CASE WHEN is_secret THEN LEFT(value, 10) || '...' ELSE value END as display_value,
--        description, category 
-- FROM system_settings 
-- ORDER BY category, key;