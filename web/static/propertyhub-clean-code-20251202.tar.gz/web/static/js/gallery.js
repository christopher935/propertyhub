// Image gallery functionality  
console.log('Gallery functionality loaded');
