-- Landlords of Texas Database Schema
-- Real Estate Platform

-- Note: Database 'landlords_of_texas' is created by Docker environment

-- Properties table with HAR-compliant schema
CREATE TABLE IF NOT EXISTS properties (
    id SERIAL PRIMARY KEY,
    mls_id VARCHAR(50) UNIQUE,
    address TEXT NOT NULL,
    city VARCHAR(100),
    state VARCHAR(50),
    zip_code VARCHAR(20),
    price DECIMAL(12,2),
    description TEXT,
    images TEXT[], -- PostgreSQL array for multiple images
    listing_type VARCHAR(50),
    status VARCHAR(50) DEFAULT 'pending_images',
    listing_agent VARCHAR(200),
    listing_office VARCHAR(200),
    bedrooms INTEGER,
    bathrooms DECIMAL(3,1),
    square_feet INTEGER,
    property_type VARCHAR(100),
    source VARCHAR(50) DEFAULT 'HAR',
    har_url TEXT,
    featured_image TEXT,
    amenities TEXT,
    date_added TIMESTAMP,
    last_updated TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Admin users table
CREATE TABLE IF NOT EXISTS admin_users (
    id VARCHAR(50) PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(200) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role VARCHAR(50) DEFAULT 'admin',
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0
);

-- SECURITY FIX: Default admin user removed for security
-- Admin users must be created through secure setup process
-- Use scripts/generate_admin_hash.go to create initial admin user

-- Sample properties (Christopher Gross portfolio)
INSERT INTO properties (
    mls_id, address, city, state, zip_code, price, description,
    listing_type, status, listing_agent, listing_office,
    bedrooms, bathrooms, square_feet, property_type, source
) VALUES 
(
    '20420686',
    '123 Main Street',
    'Houston',
    'TX',
    '77001',
    259000.00,
    'Beautiful contemporary home with modern amenities and great location.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    3,
    2.0,
    1500,
    'Contemporary/Modern',
    'HAR'
),
(
    '8352969',
    '456 Oak Avenue',
    'Sugar Land',
    'TX',
    '77478',
    434989.00,
    'Stunning traditional home in desirable neighborhood.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    4,
    3.0,
    2200,
    'Traditional',
    'HAR'
),
(
    '45780172',
    '789 Pine Street',
    'Katy',
    'TX',
    '77494',
    165000.00,
    'Charming starter home with great potential.',
    'For Sale',
    'pending_images',
    'Christopher Gross',
    'Landlords of Texas, LLC',
    2,
    1.5,
    1200,
    'Traditional',
    'HAR'
) ON CONFLICT (mls_id) DO NOTHING;

-- Bookings table (missing from schema but used in models)
CREATE TABLE IF NOT EXISTS bookings (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    fub_lead_id VARCHAR(100),
    client_name VARCHAR(200) NOT NULL,
    client_phone VARCHAR(20),
    client_email VARCHAR(200),
    showing_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    service_type VARCHAR(100),
    preferred_time VARCHAR(50),
    reference_number VARCHAR(50) UNIQUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contacts table (used in models)
CREATE TABLE IF NOT EXISTS contacts (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(200),
    phone VARCHAR(20),
    message TEXT,
    source VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Property photos table (used in models)
CREATE TABLE IF NOT EXISTS property_photos (
    id SERIAL PRIMARY KEY,
    property_id INTEGER REFERENCES properties(id),
    mls_id VARCHAR(50),
    file_path TEXT NOT NULL,
    file_hash VARCHAR(64),
    is_primary BOOLEAN DEFAULT false,
    is_active BOOLEAN DEFAULT true,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Lead reengagement table (used in models) 
CREATE TABLE IF NOT EXISTS lead_reengagement (
    id SERIAL PRIMARY KEY,
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(20),
    last_activity TIMESTAMP,
    campaign_status VARCHAR(50) DEFAULT 'active',
    engagement_score INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create comprehensive indexes for performance optimization
-- Single column indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_city ON properties(city);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_status ON properties(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_price ON properties(price);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_listing_type ON properties(listing_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_admin_users_email ON admin_users(email);

-- CRITICAL MISSING INDEXES (High Performance Impact)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_mls_id ON properties(mls_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_updated_at ON properties(updated_at);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_created_at ON properties(created_at);

-- Compound indexes for common query patterns
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_city_status ON properties(city, status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_status_price ON properties(status, price);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_properties_listing_type_status ON properties(listing_type, status);

-- Bookings table indexes (High Performance Impact)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_property_id ON bookings(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_fub_lead_id ON bookings(fub_lead_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_showing_date ON bookings(showing_date);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_reference_number ON bookings(reference_number);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_bookings_created_at ON bookings(created_at);

-- Property photos indexes (High Performance Impact)
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id ON property_photos(property_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_mls_id ON property_photos(mls_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_file_hash ON property_photos(file_hash);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id_active ON property_photos(property_id, is_active);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_property_photos_property_id_primary ON property_photos(property_id, is_primary, is_active);

-- Contacts table indexes  
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_email ON contacts(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_contacts_created_at ON contacts(created_at);

-- Lead reengagement indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_email ON lead_reengagement(email);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_last_activity ON lead_reengagement(last_activity);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_lead_reengagement_campaign_status ON lead_reengagement(campaign_status);

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ubuntu;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ubuntu;

-- HAR Market Data tables for scraping HAR reports and market intelligence

-- HAR Market Data table
CREATE TABLE IF NOT EXISTS har_market_data (
    id SERIAL PRIMARY KEY,
    report_type VARCHAR(100) NOT NULL,
    title TEXT NOT NULL,
    url TEXT UNIQUE NOT NULL,
    publish_date TIMESTAMP NOT NULL,
    content TEXT,
    summary TEXT,
    key_metrics JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'active',
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- HAR Scraping logs table
CREATE TABLE IF NOT EXISTS har_scrape_logs (
    id SERIAL PRIMARY KEY,
    scrape_type VARCHAR(100) NOT NULL,
    url TEXT NOT NULL,
    status VARCHAR(50) NOT NULL,
    items_found INTEGER DEFAULT 0,
    items_new INTEGER DEFAULT 0,
    items_updated INTEGER DEFAULT 0,
    error_message TEXT,
    duration INTEGER DEFAULT 0, -- in milliseconds
    scraped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- HAR Market Data indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_report_type ON har_market_data(report_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_publish_date ON har_market_data(publish_date DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_status ON har_market_data(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_scraped_at ON har_market_data(scraped_at DESC);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_market_data_url_hash ON har_market_data USING HASH(url);

-- HAR Scrape logs indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_scrape_type ON har_scrape_logs(scrape_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_status ON har_scrape_logs(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_har_scrape_logs_scraped_at ON har_scrape_logs(scraped_at DESC);

-- Webhook Events table for tracking all incoming webhooks
CREATE TABLE IF NOT EXISTS webhook_events (
    id SERIAL PRIMARY KEY,
    source VARCHAR(50) NOT NULL,
    event_type VARCHAR(100) NOT NULL,
    payload TEXT,
    headers TEXT,
    signature VARCHAR(255),
    processed_at TIMESTAMP,
    status VARCHAR(50) DEFAULT 'pending',
    error_msg TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Automation Rules table for SMS/Email automation
CREATE TABLE IF NOT EXISTS automation_rules (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    trigger_type VARCHAR(100) NOT NULL,
    conditions JSONB DEFAULT '{}',
    message_type VARCHAR(50) NOT NULL,
    template TEXT,
    delay_hours INTEGER DEFAULT 0,
    active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Automation Executions table for tracking automation runs
CREATE TABLE IF NOT EXISTS automation_executions (
    id SERIAL PRIMARY KEY,
    rule_id INTEGER REFERENCES automation_rules(id),
    contact_id VARCHAR(100) NOT NULL,
    trigger_data JSONB DEFAULT '{}',
    status VARCHAR(50) DEFAULT 'pending',
    sent_at TIMESTAMP,
    error_msg TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Calendar Events table for Follow Up Boss integration
CREATE TABLE IF NOT EXISTS calendar_events (
    id SERIAL PRIMARY KEY,
    fub_event_id VARCHAR(100) UNIQUE,
    title VARCHAR(500) NOT NULL,
    description TEXT,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP NOT NULL,
    location VARCHAR(500),
    contact_id VARCHAR(100),
    property_id VARCHAR(100),
    event_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) DEFAULT 'scheduled',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Webhook Events indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_source ON webhook_events(source);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_event_type ON webhook_events(event_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_status ON webhook_events(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_webhook_events_created_at ON webhook_events(created_at DESC);

-- Automation Rules indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_rules_trigger_type ON automation_rules(trigger_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_rules_active ON automation_rules(active);

-- Automation Executions indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_rule_id ON automation_executions(rule_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_contact_id ON automation_executions(contact_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_status ON automation_executions(status);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_automation_executions_created_at ON automation_executions(created_at DESC);

-- Calendar Events indexes
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_fub_event_id ON calendar_events(fub_event_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_start_time ON calendar_events(start_time);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_contact_id ON calendar_events(contact_id);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_event_type ON calendar_events(event_type);
CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_calendar_events_status ON calendar_events(status);

-- Grant permissions for new tables
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO ubuntu;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO ubuntu;

-- Performance optimization comments
-- CONCURRENTLY keyword prevents blocking during index creation
-- Compound indexes optimize common WHERE clause combinations
-- Hash indexes optimize exact match lookups (file_hash, url)
-- Timestamp indexes enable efficient date range queries and ordering
-- JSONB indexes enable efficient key_metrics querying
