-- Advanced Security Features Database Migration
-- Landlords of Texas - Comprehensive Security Implementation
-- This migration adds all tables and indexes needed for advanced security features

-- Enable UUID extension for better security
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Security Users Table (Enhanced)
CREATE TABLE IF NOT EXISTS security_users (
    id SERIAL PRIMARY KEY,
    uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255),
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    last_login TIMESTAMP,
    login_count INTEGER DEFAULT 0,
    failed_login_attempts INTEGER DEFAULT 0,
    locked_until TIMESTAMP,
    password_changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    two_factor_enabled BOOLEAN DEFAULT false,
    two_factor_secret VARCHAR(255),
    backup_codes TEXT[],
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Security Roles Table
CREATE TABLE IF NOT EXISTS security_roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    is_system_role BOOLEAN DEFAULT false,
    hierarchy_level INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Security Permissions Table
CREATE TABLE IF NOT EXISTS security_permissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    resource VARCHAR(50) NOT NULL,
    action VARCHAR(20) NOT NULL,
    is_system_permission BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- User Roles Junction Table
CREATE TABLE IF NOT EXISTS user_roles (
    user_id INTEGER REFERENCES security_users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES security_roles(id) ON DELETE CASCADE,
    assigned_by INTEGER REFERENCES security_users(id),
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    PRIMARY KEY (user_id, role_id)
);

-- Role Permissions Junction Table
CREATE TABLE IF NOT EXISTS role_permissions (
    role_id INTEGER REFERENCES security_roles(id) ON DELETE CASCADE,
    permission_id INTEGER REFERENCES security_permissions(id) ON DELETE CASCADE,
    granted_by INTEGER REFERENCES security_users(id),
    granted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (role_id, permission_id)
);

-- Security Sessions Table (Enhanced)
CREATE TABLE IF NOT EXISTS security_sessions (
    id SERIAL PRIMARY KEY,
    session_token VARCHAR(255) NOT NULL UNIQUE,
    refresh_token VARCHAR(255) UNIQUE,
    user_id INTEGER REFERENCES security_users(id) ON DELETE CASCADE,
    ip_address INET,
    user_agent TEXT,
    device_fingerprint VARCHAR(255),
    location_country VARCHAR(2),
    location_city VARCHAR(100),
    is_active BOOLEAN DEFAULT true,
    is_trusted_device BOOLEAN DEFAULT false,
    expires_at TIMESTAMP NOT NULL,
    refresh_expires_at TIMESTAMP NOT NULL,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Security Events/Audit Log Table (Enhanced)
CREATE TABLE IF NOT EXISTS security_events (
    id SERIAL PRIMARY KEY,
    event_id UUID DEFAULT uuid_generate_v4() UNIQUE,
    user_id INTEGER REFERENCES security_users(id) ON DELETE SET NULL,
    session_id INTEGER REFERENCES security_sessions(id) ON DELETE SET NULL,
    event_type VARCHAR(50) NOT NULL,
    event_category VARCHAR(30) NOT NULL DEFAULT 'general',
    description TEXT NOT NULL,
    ip_address INET,
    user_agent TEXT,
    device_fingerprint VARCHAR(255),
    location_country VARCHAR(2),
    location_city VARCHAR(100),
    severity VARCHAR(20) NOT NULL DEFAULT 'low',
    risk_score INTEGER DEFAULT 0,
    metadata JSONB,
    resource_type VARCHAR(50),
    resource_id VARCHAR(100),
    before_value JSONB,
    after_value JSONB,
    is_anomaly BOOLEAN DEFAULT false,
    is_resolved BOOLEAN DEFAULT false,
    resolved_by INTEGER REFERENCES security_users(id) ON DELETE SET NULL,
    resolved_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Security Alerts Table
CREATE TABLE IF NOT EXISTS security_alerts (
    id SERIAL PRIMARY KEY,
    alert_id UUID DEFAULT uuid_generate_v4() UNIQUE,
    alert_type VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(20) NOT NULL,
    threat_level VARCHAR(20) NOT NULL DEFAULT 'low',
    ip_address INET,
    user_id INTEGER REFERENCES security_users(id) ON DELETE SET NULL,
    event_ids INTEGER[],
    metadata JSONB,
    auto_generated BOOLEAN DEFAULT true,
    is_acknowledged BOOLEAN DEFAULT false,
    acknowledged_by INTEGER REFERENCES security_users(id) ON DELETE SET NULL,
    acknowledged_at TIMESTAMP,
    is_resolved BOOLEAN DEFAULT false,
    resolved_by INTEGER REFERENCES security_users(id) ON DELETE SET NULL,
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Security Configuration Table
CREATE TABLE IF NOT EXISTS security_configuration (
    id SERIAL PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value JSONB NOT NULL,
    description TEXT,
    is_sensitive BOOLEAN DEFAULT false,
    updated_by INTEGER REFERENCES security_users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Password History Table (for password reuse prevention)
CREATE TABLE IF NOT EXISTS password_history (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES security_users(id) ON DELETE CASCADE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Trusted Devices Table
CREATE TABLE IF NOT EXISTS trusted_devices (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES security_users(id) ON DELETE CASCADE,
    device_fingerprint VARCHAR(255) NOT NULL,
    device_name VARCHAR(100),
    device_type VARCHAR(50),
    user_agent TEXT,
    is_trusted BOOLEAN DEFAULT true,
    last_used TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, device_fingerprint)
);

-- Security Blacklist Table (for blocked IPs, emails, etc.)
CREATE TABLE IF NOT EXISTS security_blacklist (
    id SERIAL PRIMARY KEY,
    entry_type VARCHAR(20) NOT NULL, -- 'ip', 'email', 'user_agent'
    entry_value VARCHAR(255) NOT NULL,
    reason TEXT,
    blocked_by INTEGER REFERENCES security_users(id),
    is_active BOOLEAN DEFAULT true,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(entry_type, entry_value)
);

-- Rate Limiting Table
CREATE TABLE IF NOT EXISTS rate_limits (
    id SERIAL PRIMARY KEY,
    identifier VARCHAR(255) NOT NULL, -- IP address, user ID, etc.
    endpoint VARCHAR(255) NOT NULL,
    request_count INTEGER DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_blocked BOOLEAN DEFAULT false,
    block_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(identifier, endpoint)
);

-- Security Metrics Table (for performance monitoring)
CREATE TABLE IF NOT EXISTS security_metrics (
    id SERIAL PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value NUMERIC NOT NULL,
    metric_type VARCHAR(50) NOT NULL, -- 'counter', 'gauge', 'histogram'
    labels JSONB,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (metric_name, recorded_at)
);

-- ================================
-- INDEXES FOR PERFORMANCE
-- ================================

-- Security Users Indexes
CREATE INDEX IF NOT EXISTS idx_security_users_email ON security_users(email);
CREATE INDEX IF NOT EXISTS idx_security_users_username ON security_users(username);
CREATE INDEX IF NOT EXISTS idx_security_users_active ON security_users(is_active);
CREATE INDEX IF NOT EXISTS idx_security_users_last_login ON security_users(last_login);
CREATE INDEX IF NOT EXISTS idx_security_users_locked_until ON security_users(locked_until);

-- Security Sessions Indexes
CREATE INDEX IF NOT EXISTS idx_security_sessions_user_id ON security_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_security_sessions_token ON security_sessions(session_token);
CREATE INDEX IF NOT EXISTS idx_security_sessions_active ON security_sessions(is_active);
CREATE INDEX IF NOT EXISTS idx_security_sessions_expires_at ON security_sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_security_sessions_ip_address ON security_sessions(ip_address);
CREATE INDEX IF NOT EXISTS idx_security_sessions_last_activity ON security_sessions(last_activity);

-- Security Events Indexes (Critical for performance)
CREATE INDEX IF NOT EXISTS idx_security_events_user_id ON security_events(user_id);
CREATE INDEX IF NOT EXISTS idx_security_events_event_type ON security_events(event_type);
CREATE INDEX IF NOT EXISTS idx_security_events_severity ON security_events(severity);
CREATE INDEX IF NOT EXISTS idx_security_events_created_at ON security_events(created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_ip_address ON security_events(ip_address);
CREATE INDEX IF NOT EXISTS idx_security_events_anomaly ON security_events(is_anomaly);
CREATE INDEX IF NOT EXISTS idx_security_events_resolved ON security_events(is_resolved);
CREATE INDEX IF NOT EXISTS idx_security_events_category ON security_events(event_category);
CREATE INDEX IF NOT EXISTS idx_security_events_risk_score ON security_events(risk_score);

-- Composite indexes for common queries
CREATE INDEX IF NOT EXISTS idx_security_events_type_severity_date ON security_events(event_type, severity, created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_user_date ON security_events(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_security_events_ip_date ON security_events(ip_address, created_at);

-- Security Alerts Indexes
CREATE INDEX IF NOT EXISTS idx_security_alerts_severity ON security_alerts(severity);
CREATE INDEX IF NOT EXISTS idx_security_alerts_resolved ON security_alerts(is_resolved);
CREATE INDEX IF NOT EXISTS idx_security_alerts_acknowledged ON security_alerts(is_acknowledged);
CREATE INDEX IF NOT EXISTS idx_security_alerts_created_at ON security_alerts(created_at);
CREATE INDEX IF NOT EXISTS idx_security_alerts_ip_address ON security_alerts(ip_address);

-- User Roles Indexes
CREATE INDEX IF NOT EXISTS idx_user_roles_user_id ON user_roles(user_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_role_id ON user_roles(role_id);
CREATE INDEX IF NOT EXISTS idx_user_roles_expires_at ON user_roles(expires_at);

-- Role Permissions Indexes
CREATE INDEX IF NOT EXISTS idx_role_permissions_role_id ON role_permissions(role_id);
CREATE INDEX IF NOT EXISTS idx_role_permissions_permission_id ON role_permissions(permission_id);

-- Password History Indexes
CREATE INDEX IF NOT EXISTS idx_password_history_user_id ON password_history(user_id);
CREATE INDEX IF NOT EXISTS idx_password_history_created_at ON password_history(created_at);

-- Trusted Devices Indexes
CREATE INDEX IF NOT EXISTS idx_trusted_devices_user_id ON trusted_devices(user_id);
CREATE INDEX IF NOT EXISTS idx_trusted_devices_fingerprint ON trusted_devices(device_fingerprint);
CREATE INDEX IF NOT EXISTS idx_trusted_devices_expires_at ON trusted_devices(expires_at);

-- Security Blacklist Indexes
CREATE INDEX IF NOT EXISTS idx_security_blacklist_type_value ON security_blacklist(entry_type, entry_value);
CREATE INDEX IF NOT EXISTS idx_security_blacklist_active ON security_blacklist(is_active);
CREATE INDEX IF NOT EXISTS idx_security_blacklist_expires_at ON security_blacklist(expires_at);

-- Rate Limits Indexes
CREATE INDEX IF NOT EXISTS idx_rate_limits_identifier_endpoint ON rate_limits(identifier, endpoint);
CREATE INDEX IF NOT EXISTS idx_rate_limits_window_start ON rate_limits(window_start);
CREATE INDEX IF NOT EXISTS idx_rate_limits_blocked ON rate_limits(is_blocked);

-- Security Metrics Indexes
CREATE INDEX IF NOT EXISTS idx_security_metrics_name_time ON security_metrics(metric_name, recorded_at);
CREATE INDEX IF NOT EXISTS idx_security_metrics_type ON security_metrics(metric_type);

-- ================================
-- TRIGGER FUNCTIONS FOR AUTOMATION
-- ================================

-- Function to update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply updated_at triggers
CREATE TRIGGER update_security_users_updated_at BEFORE UPDATE ON security_users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_roles_updated_at BEFORE UPDATE ON security_roles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_permissions_updated_at BEFORE UPDATE ON security_permissions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_sessions_updated_at BEFORE UPDATE ON security_sessions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_alerts_updated_at BEFORE UPDATE ON security_alerts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_configuration_updated_at BEFORE UPDATE ON security_configuration FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_security_blacklist_updated_at BEFORE UPDATE ON security_blacklist FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_rate_limits_updated_at BEFORE UPDATE ON rate_limits FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to automatically clean up expired sessions
CREATE OR REPLACE FUNCTION cleanup_expired_sessions()
RETURNS void AS $$
BEGIN
    -- Deactivate expired sessions
    UPDATE security_sessions 
    SET is_active = false 
    WHERE expires_at < CURRENT_TIMESTAMP AND is_active = true;
    
    -- Delete old inactive sessions (older than 30 days)
    DELETE FROM security_sessions 
    WHERE expires_at < CURRENT_TIMESTAMP - INTERVAL '30 days';
END;
$$ language 'plpgsql';

-- Function to automatically clean up old audit logs
CREATE OR REPLACE FUNCTION cleanup_old_audit_logs()
RETURNS void AS $$
BEGIN
    -- Delete audit logs older than 1 year (configurable)
    DELETE FROM security_events 
    WHERE created_at < CURRENT_TIMESTAMP - INTERVAL '1 year';
    
    -- Delete resolved alerts older than 90 days
    DELETE FROM security_alerts 
    WHERE is_resolved = true AND resolved_at < CURRENT_TIMESTAMP - INTERVAL '90 days';
END;
$$ language 'plpgsql';

-- ================================
-- DEFAULT DATA AND CONFIGURATION
-- ================================

-- Insert default security configuration
INSERT INTO security_configuration (config_key, config_value, description) VALUES
('session_timeout', '1800', 'Session timeout in seconds (30 minutes)'),
('max_failed_login_attempts', '5', 'Maximum failed login attempts before lockout'),
('account_lockout_duration', '900', 'Account lockout duration in seconds (15 minutes)'),
('password_min_length', '12', 'Minimum password length'),
('password_complexity_level', '3', 'Password complexity level (1-4)'),
('mfa_required', 'false', 'Whether MFA is required for all users'),
('audit_log_retention_days', '365', 'Number of days to retain audit logs'),
('session_cleanup_interval', '3600', 'Session cleanup interval in seconds (1 hour)'),
('rate_limit_window_minutes', '60', 'Rate limiting window in minutes'),
('max_requests_per_window', '1000', 'Maximum requests per rate limit window')
ON CONFLICT (config_key) DO NOTHING;

-- Create default system permissions
INSERT INTO security_permissions (name, description, resource, action, is_system_permission) VALUES
('admin.full_access', 'Full administrative access to all system resources', 'admin', 'all', true),
('users.read', 'View user information and profiles', 'users', 'read', true),
('users.write', 'Create, update, and manage user accounts', 'users', 'write', true),
('users.delete', 'Delete user accounts', 'users', 'delete', true),
('roles.read', 'View roles and permissions', 'roles', 'read', true),
('roles.write', 'Create and modify roles', 'roles', 'write', true),
('roles.delete', 'Delete roles', 'roles', 'delete', true),
('permissions.read', 'View system permissions', 'permissions', 'read', true),
('permissions.write', 'Create and modify permissions', 'permissions', 'write', true),
('security.read', 'View security settings and logs', 'security', 'read', true),
('security.write', 'Modify security settings and configurations', 'security', 'write', true),
('properties.read', 'View property information', 'properties', 'read', true),
('properties.write', 'Create and edit properties', 'properties', 'write', true),
('properties.delete', 'Delete properties', 'properties', 'delete', true),
('bookings.read', 'View booking information', 'bookings', 'read', true),
('bookings.write', 'Create and manage bookings', 'bookings', 'write', true),
('bookings.delete', 'Delete bookings', 'bookings', 'delete', true),
('analytics.read', 'View analytics and reports', 'analytics', 'read', true),
('analytics.write', 'Modify analytics settings', 'analytics', 'write', true)
ON CONFLICT (name) DO NOTHING;

-- Create default system roles
INSERT INTO security_roles (name, description, is_system_role, hierarchy_level) VALUES
('Super Administrator', 'Full system access with all permissions', true, 100),
('Administrator', 'Administrative access to most system functions', true, 90),
('Security Administrator', 'Specialized role for security management', true, 85),
('Property Manager', 'Full property and booking management access', true, 70),
('Senior Agent', 'Enhanced agent access with analytics', true, 60),
('Agent', 'Standard agent access for properties and bookings', true, 50),
('Analyst', 'Analytics and reporting access', true, 40),
('Viewer', 'Read-only access to basic information', true, 10)
ON CONFLICT (name) DO NOTHING;

-- Assign permissions to Super Administrator role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Super Administrator' AND p.name = 'admin.full_access'
ON CONFLICT DO NOTHING;

-- Assign permissions to Administrator role (most permissions except sensitive ones)
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Administrator' 
AND p.name IN ('users.read', 'users.write', 'roles.read', 'security.read', 'properties.read', 'properties.write', 'properties.delete', 'bookings.read', 'bookings.write', 'bookings.delete', 'analytics.read', 'analytics.write')
ON CONFLICT DO NOTHING;

-- Assign permissions to Security Administrator role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Security Administrator' 
AND p.name IN ('users.read', 'roles.read', 'roles.write', 'permissions.read', 'security.read', 'security.write')
ON CONFLICT DO NOTHING;

-- Assign permissions to Property Manager role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Property Manager' 
AND p.name IN ('properties.read', 'properties.write', 'properties.delete', 'bookings.read', 'bookings.write', 'bookings.delete', 'analytics.read')
ON CONFLICT DO NOTHING;

-- Assign permissions to Agent role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Agent' 
AND p.name IN ('properties.read', 'bookings.read', 'bookings.write', 'analytics.read')
ON CONFLICT DO NOTHING;

-- Assign permissions to Viewer role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id 
FROM security_roles r, security_permissions p 
WHERE r.name = 'Viewer' 
AND p.name IN ('properties.read', 'bookings.read', 'analytics.read')
ON CONFLICT DO NOTHING;

-- ================================
-- PERFORMANCE OPTIMIZATION VIEWS
-- ================================

-- View for active user sessions
CREATE OR REPLACE VIEW active_user_sessions AS
SELECT 
    u.id as user_id,
    u.username,
    u.email,
    s.session_token,
    s.ip_address,
    s.user_agent,
    s.last_activity,
    s.expires_at,
    EXTRACT(EPOCH FROM (s.expires_at - CURRENT_TIMESTAMP))/60 as minutes_until_expiry
FROM security_users u
JOIN security_sessions s ON u.id = s.user_id
WHERE s.is_active = true AND s.expires_at > CURRENT_TIMESTAMP;

-- View for security event summary
CREATE OR REPLACE VIEW security_event_summary AS
SELECT 
    DATE(created_at) as event_date,
    event_type,
    severity,
    COUNT(*) as event_count,
    COUNT(DISTINCT ip_address) as unique_ips,
    COUNT(DISTINCT user_id) as unique_users
FROM security_events
WHERE created_at >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY DATE(created_at), event_type, severity
ORDER BY event_date DESC, event_count DESC;

-- View for user permission summary
CREATE OR REPLACE VIEW user_permissions_summary AS
SELECT 
    u.id as user_id,
    u.username,
    u.email,
    r.name as role_name,
    r.hierarchy_level,
    array_agg(p.name ORDER BY p.name) as permissions
FROM security_users u
JOIN user_roles ur ON u.id = ur.user_id
JOIN security_roles r ON ur.role_id = r.id
JOIN role_permissions rp ON r.id = rp.role_id
JOIN security_permissions p ON rp.permission_id = p.id
WHERE u.is_active = true AND r.is_active = true
AND (ur.expires_at IS NULL OR ur.expires_at > CURRENT_TIMESTAMP)
GROUP BY u.id, u.username, u.email, r.name, r.hierarchy_level
ORDER BY r.hierarchy_level DESC, u.username;

-- ================================
-- COMPLETION MESSAGE
-- ================================

-- Add comment to mark completion
COMMENT ON SCHEMA public IS 'Advanced Security Features Migration Completed - Landlords of Texas Platform';

SELECT 'Advanced Security Features Migration Completed Successfully!' as status;
