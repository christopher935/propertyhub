// Booking calendar functionality
console.log('Booking calendar loaded');
